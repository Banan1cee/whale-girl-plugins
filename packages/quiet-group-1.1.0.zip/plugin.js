'use strict';

/**
 * 群聊安静模式 · whale-plugin/1 / 4 级 node-full
 *
 * 在宿主前置闸之后、决定是否回复与生成之前，只对名单内的微信群拦截普通消息；
 * 明确 @ 机器人时继续放行。已确认 @ 的判定保留；旧协议里的 replyToBot 字段
 * 在当前 chat.pre_reply@1 输入 schema 中不存在，因此引用回复只能按 @ 处理。
 */
exports.providers = {
  'chat.pre_reply@1': async (input, context) => {
    const message = input?.message;
    if (!message || message.platform !== 'wechat' || message.chatType !== 'group') {
      return { action: 'pass' };
    }
    const groups = String(context?.settings?.groups ?? '')
      .split(/[,，\s]+/)
      .map(item => item.trim())
      .filter(Boolean);
    if (!groups.includes(message.chatId)) return { action: 'pass' };
    // 当前协议没有 replyToBot；保留读取是为了宿主未来补字段时不改插件语义。
    const quoted = message.replyToBot === true;
    return quoted || message.atMe === true
      ? { action: 'pass' }
      : { action: 'skip', reason: 'quiet-group: muted ordinary group message' };
  },
};
