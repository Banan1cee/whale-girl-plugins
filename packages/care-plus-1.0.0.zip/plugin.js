"use strict";

// care-plus 4 级迁移版。
// 新协议没有：官方 care 设置读取、自动关闭官方 care、/api/debug/prompt、/api/care/sent 记账、
// 宿主私有文件布局。以下只用清单声明的真实 calls；拿不到的降级并在 README 说明。
const DEFAULTS = {
  minIntervalMinutes: 25, maxIntervalMinutes: 300, maxPerDay: 5,
  bootSilentMinutes: 30, maxChars: 60, dryRun: false,
};

const state = { firstSeenAt: 0, day: "", sentToday: 0, sessions: {} };

function fail(code, message) { return { ok: false, code: code, message: message }; }
function intIn(value, fallback, min, max) {
  const n = Math.trunc(Number(value));
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}
function settingsOf(raw) {
  const s = raw || {};
  return {
    targets: String(s.targets || "").split(/[\n,，;；\s]+/).map((x) => x.trim()).filter(Boolean),
    windows: String(s.windows || "").split(/[\s,，;；]+/).filter(Boolean),
    minIntervalMinutes: intIn(s.minIntervalMinutes, DEFAULTS.minIntervalMinutes, 1, 43200),
    maxIntervalMinutes: intIn(s.maxIntervalMinutes, DEFAULTS.maxIntervalMinutes, 1, 43200),
    maxPerDay: intIn(s.maxPerDay, DEFAULTS.maxPerDay, 0, 50),
    bootSilentMinutes: intIn(s.bootSilentMinutes, DEFAULTS.bootSilentMinutes, 0, 1440),
    maxChars: intIn(s.maxChars, DEFAULTS.maxChars, 12, 200),
    dryRun: s.dryRun === true,
  };
}
function minutesOf(text) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(text || "").trim());
  if (!m) return null;
  const h = Number(m[1]), mm = Number(m[2]);
  return h <= 23 && mm <= 59 ? h * 60 + mm : null;
}
function parseWindows(list) {
  const out = [];
  for (const piece of list || []) {
    const m = /^(\d{1,2}:\d{2})\s*[-~到]\s*(\d{1,2}:\d{2})$/.exec(String(piece));
    if (!m) continue;
    const a = minutesOf(m[1]), b = minutesOf(m[2]);
    if (a != null && b != null) out.push([a, b]);
  }
  return out;
}
function inWindows(nowMinutes, windows) {
  if (!windows.length) return true;
  return windows.some(([a, b]) => (a <= b ? nowMinutes >= a && nowMinutes <= b : nowMinutes >= a || nowMinutes <= b));
}
function today(now) {
  const d = new Date(now);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function bigrams(text) {
  const clean = String(text || "").replace(/[\s\p{P}]/gu, "");
  const set = new Set();
  for (let i = 0; i < clean.length - 1; i += 1) set.add(clean.slice(i, i + 2));
  return set;
}
function similarity(a, b) {
  const left = bigrams(a), right = bigrams(b);
  if (!left.size || !right.size) return 0;
  let hit = 0;
  for (const gram of left) if (right.has(gram)) hit += 1;
  return (2 * hit) / (left.size + right.size);
}
function messageTime(m) {
  const value = Number(m && (m.ts ?? m.time ?? m.createdAt ?? m.at));
  return Number.isFinite(value) ? value : 0;
}
function messageText(m) { return String((m && (m.text ?? m.content)) || ""); }
function messageRole(m) { return String((m && (m.role || m.by)) || "").toLowerCase(); }

async function recent(host, chatId) {
  const out = await host.call("memory.recent@1", { chatId: chatId, limit: 12 });
  return Array.isArray(out && out.messages) ? out.messages : [];
}

function systemPrompt(persona) {
  return [
    "你在主动找人说话（不是回复用户）。只输出一句自然的中文短句。",
    "禁止编造动作、场景、系统状态；不要汇报你做了什么；不要重复最近说过的话。",
    "人设：名字 " + (persona.name || "鲸鲸") + "；语气 " + (persona.tone || "自然") + "；风格 " + (persona.style || "简短") + "。",
  ].join("\n");
}

async function compose(host, chatId, settings, persona) {
  const messages = await recent(host, chatId);
  const history = messages.slice(-6).map((m) => ({ role: messageRole(m) === "assistant" ? "assistant" : "user", text: messageText(m).slice(0, 300) }));
  const out = await host.call("model.complete@1", {
    system: systemPrompt(persona), turns: history.concat([{ role: "user", text: "现在写一句主动开口的话。" }]),
    maxTokens: Math.max(32, settings.maxChars * 4),
  });
  const text = String((out && out.text) || "").replace(/\s+/g, " ").trim().slice(0, settings.maxChars);
  if (!text) throw Object.assign(new Error("模型没有返回内容"), { code: "empty_completion" });
  return { text: text, messages: messages };
}

async function candidates(host, chatId, settings, persona, count) {
  const first = await compose(host, chatId, settings, persona);
  const lines = [first.text];
  for (let i = 1; i < count; i += 1) {
    try { lines.push((await compose(host, chatId, settings, persona)).text); } catch (error) { break; }
  }
  const recentAssistant = first.messages.filter((m) => messageRole(m) === "assistant").map(messageText);
  return lines
    .map((line, index) => ({ line: line, index: index,
      score: (1 - Math.max(0, ...recentAssistant.map((old) => similarity(old, line)))) * 0.6 }))
    .sort((a, b) => b.score - a.score);
}

async function dueTargets(host, settings, now, persona) {
  const targets = [];
  for (const chatId of settings.targets) {
    const messages = await recent(host, chatId);
    const lastUser = messages.filter((m) => messageRole(m) !== "assistant" && messageText(m)).map(messageTime).sort((a, b) => b - a)[0] || 0;
    const session = state.sessions[chatId] || (state.sessions[chatId] = { nextAt: 0, lastLines: [], unanswered: 0 });
    if (!session.nextAt) session.nextAt = now + 0;
    if (now < session.nextAt) continue;
    const since = lastUser ? now - lastUser : Infinity;
    const gapMinutes = settings.minIntervalMinutes + Math.floor(Math.random() * Math.max(1, settings.maxIntervalMinutes - settings.minIntervalMinutes));
    if (since < gapMinutes * 60000) continue;
    targets.push({ chatId: chatId, sinceMinutes: Math.floor(since / 60000), gapMinutes: gapMinutes, session: session });
  }
  if (!targets.length) {
    // 没有配置目标时，只把 care.decide@1 当作建议，不伪造多目标调度。
    try {
      const advice = await host.call("care.decide@1", {});
      if (advice && advice.due && advice.target && advice.target.wxid) {
        const session = state.sessions[advice.target.wxid] || (state.sessions[advice.target.wxid] = { nextAt: 0, lastLines: [], unanswered: 0 });
        targets.push({ chatId: advice.target.wxid, sinceMinutes: null, gapMinutes: null, session: session, advice: true });
      }
    } catch (error) { /* 建议能力失败不影响自主目标 */ }
  }
  return targets;
}

async function runTick(host, input) {
  const settings = settingsOf(input && input.settings);
  const now = Number(input && input.now) || Date.now();
  if (!state.firstSeenAt) state.firstSeenAt = now;
  const day = today(now);
  if (state.day !== day) { state.day = day; state.sentToday = 0; }
  if (settings.maxPerDay === 0) return { ok: true, action: "tick", skipped: "daily_limit_zero" };
  if (now - state.firstSeenAt < settings.bootSilentMinutes * 60000) return { ok: true, action: "tick", skipped: "boot_silent" };
  const minutes = new Date(now).getHours() * 60 + new Date(now).getMinutes();
  if (!inWindows(minutes, parseWindows(settings.windows))) return { ok: true, action: "tick", skipped: "outside_window" };
  const persona = await host.call("persona.read@1", {});
  const targets = await dueTargets(host, settings, now, persona);
  if (!targets.length) return { ok: true, action: "tick", skipped: "no_due_target" };
  const target = targets.sort((a, b) => (b.sinceMinutes || 0) - (a.sinceMinutes || 0))[0];
  const ranked = await candidates(host, target.chatId, settings, persona, 3);
  const best = ranked[0];
  if (!best) return { ok: true, action: "tick", skipped: "no_candidate" };
  const session = target.session;
  const tooSimilar = session.lastLines.some((old) => similarity(old, best.line) > 0.8);
  if (tooSimilar) return { ok: true, action: "tick", skipped: "too_similar" };
  if (settings.dryRun) {
    return { ok: true, action: "tick", dryRun: true, chatId: target.chatId, text: best.line, candidates: ranked.map((r) => r.line) };
  }
  if (state.sentToday >= settings.maxPerDay) return { ok: true, action: "tick", skipped: "daily_limit" };
  const sent = await host.call("message.send@1", {
    chatId: target.chatId, chatType: /@chatroom$/i.test(target.chatId) ? "group" : "private",
    text: best.line, name: "",
  });
  state.sentToday += 1;
  session.nextAt = now + (best.gapMinutes || settings.minIntervalMinutes) * 60000;
  session.lastLines = session.lastLines.concat([best.line]).slice(-8);
  return { ok: true, action: "tick", sent: { queued: Boolean(sent && sent.status === "queued"), id: String((sent && sent.id) || ""), status: String((sent && sent.status) || "queued") }, chatId: target.chatId, text: best.line };
}

function statusPayload(settings) {
  return {
    ok: true, action: "status", level: 4,
    sentToday: state.sentToday, day: state.day,
    targets: settings.targets, sessions: Object.keys(state.sessions),
    settings: settings,
    note: "官方 care 设置不可读、不可自动关闭；请手动关闭官方主动搭话，否则会双份开口。",
  };
}

exports.providers = {
  "task.tick@1": async (input, context) => {
    const host = context && context.host;
    if (!host || typeof host.call !== "function") return fail("host_unavailable", "宿主 SDK 不可用");
    try { return await runTick(host, input || {}); }
    catch (error) { return fail(String((error && error.code) || "tick_failed"), String((error && error.message) || error)); }
  },
  "tool.run@1": async (input, context) => {
    const host = context && context.host;
    if (!host || typeof host.call !== "function") return fail("host_unavailable", "宿主 SDK 不可用");
    const settings = settingsOf((context && context.settings) || (input && input.settings));
    const action = String((input && input.action) || "status").toLowerCase();
    try {
      if (action === "status") return statusPayload(settings);
      if (action === "tick") return await runTick(host, { now: Date.now(), settings: (context && context.settings) || {} });
      return fail("unsupported_action", "支持 status/tick（发送默认按 tick 的配置与节流）");
    } catch (error) { return fail(String((error && error.code) || "tool_failed"), String((error && error.message) || error)); }
  },
};
